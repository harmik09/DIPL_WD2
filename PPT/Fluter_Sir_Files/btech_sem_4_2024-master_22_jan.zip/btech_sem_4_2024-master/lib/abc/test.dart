void myFunction({required int a}) {
  print(a);
}

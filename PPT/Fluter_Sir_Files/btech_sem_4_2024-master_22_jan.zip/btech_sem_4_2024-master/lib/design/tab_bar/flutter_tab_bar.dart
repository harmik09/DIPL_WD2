import 'package:btech_sem_4_2024/design/login/launch_page.dart';
import 'package:btech_sem_4_2024/design/login/pre_login_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FlutterTabBarPage extends StatelessWidget {
  const FlutterTabBarPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 36,
      initialIndex: 9,
      child: Scaffold(
        appBar: AppBar(
          title: Text('TabBar'),
          bottom: TabBar(
            dividerHeight: 0,
            indicator: ShapeDecoration(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(50),
              ),
              color: Colors.red,
            ),
            isScrollable: true,
            indicatorSize: TabBarIndicatorSize.tab,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.yellow,
            tabs: [
              Tab(
                text: 'Car',
              ),
              Tab(
                text: 'Bus',
              ),
              Tab(
                text: 'Car',
              ),
              Tab(
                text: 'Bus',
              ),
              Tab(
                text: 'Car',
              ),
              Tab(
                text: 'Bus',
              ),
              Tab(
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
              Tab(
                icon: Icon(Icons.car_crash),
                text: 'Car',
              ),
              Tab(
                icon: Icon(Icons.bus_alert),
                text: 'Bus',
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: getTabPages(),
        ),
      ),
    );
  }

  List<Widget> getTabPages(){
    List<Widget> widgets = [];
    for(int i = 0;i<36;i++){
      if(i%2 == 0){
        widgets.add(LaunchPage());
      }else{
        widgets.add(PreLoginPage());
      }

    }
    return widgets;
  }
}

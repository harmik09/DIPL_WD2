package com.aswdc_demo.btech_sem_4_2024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
